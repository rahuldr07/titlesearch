# Handoff: TitlePipe — Title Report Review & Measurement Tool

## Overview
TitlePipe is the internal tool for a title-search shop moving from ~2K to ~20K orders/month. It has two halves:

1. **Production review** — orders come in as scanned packages, a multi-engine extraction layer reads them, humans triage only the flagged fields, approved orders are delivered.
2. **Measurement** — golden set, blind-fifty double-typing, extraction bench, and engine leaderboard, so the shop knows the defect rate instead of guessing. The shop has never measured defects before; this half is not optional.

Source of truth for business logic: **TitlePipe PRD v1.0 (July 2026)** — multi-engine extraction behind one interface, ensemble routing (two readers with uncorrelated failures), auto-confirm only on agreement + validation + redundancy, 24 live rules (R1–R24), Claude gate on high-stakes fields, judgments never auto-confirm in v1, phased rollout P0–P6 ending in shadow mode.

## About the Design Files
The `.dc.html` files in this bundle are **design references created in HTML** — working prototypes showing intended look and behavior, not production code to ship. The task is to **recreate these designs in the target codebase's environment** (React/Vue/etc.) using its established patterns. If no frontend environment exists yet, React + a thin fetch layer mirroring `api.js` is the natural fit — the prototypes are already structured as (template, logic class, API adapter).

Each `.dc.html` opens directly in a browser. Every screen renders from embedded fallback data when the backend is absent, and switches to live data when `http://localhost:5000` responds — preserve this dual mode during development.

`support.js` is prototype runtime only — do not port it. `api.js` IS the API contract — port it nearly verbatim.

## Fidelity
**High-fidelity.** Colors, typography, spacing, copy, and interaction states are final. Recreate pixel-perfectly. All styles are inline in the HTML — measurements can be read directly off any element.

## Design Tokens
Fonts (Google Fonts): **IBM Plex Sans** (UI, 400/600/700), **IBM Plex Mono** (order numbers, field paths, metrics, rule IDs).

- Page background `#EDEAE2` · header/panel `#F6F4EE` · card `#FFFFFF`
- Ink `#1F1C17` · secondary `#57524A` · muted `#8A857A` · faint `#A39D8F` · label caps `#6E685C`
- Borders: strong `#C9C3B5` · mid `#D8D3C7` / `#DCD7CA` · light `#E5E0D3` · hairline rows `#EEE9DD` · dashed `#B9B3A5`
- Action blue `#23508F` (chip bg `#EEF3FB`, border `#9FB4D4`) · danger red `#A9271C` · confirm green `#2E6B4F` · amber `#8A5300`/`#6B4100` (warning bg tones) · progress track `#EFEBE0`
- Radii: cards 6px, buttons 4px, chips 3px, bars 2–3px. Shadow: `0 1px 3px rgba(31,28,23,.06)` on primary cards only.
- Type scale: page numbers/metrics 20–52px mono; body 12–13px; captions 10.5–11.5px; caps-labels 10.5px/700/letter-spacing .08–.1em.
- Every screen: `height:100vh` flex column; top bar `padding:10px 18px`, bottom border `#D8D3C7`.

## Screens
All screens share the header pattern (title + nav links between screens via relative `<a>` hrefs) and the fallback/live data pattern.

**Production loop**
- **Ingest** — package upload (PDF 36–181 pages) + required manifest (grid: field / input / why). Hard-refuses incomplete packages with per-field reasons ("refusal is protection, not pedantry"). Sim buttons for no-backend demo. → `POST /api/upload`, `POST /api/orders/:id/accept`.
- **Reviewer Queue** — one big "next order" button (the reviewer never chooses), waiting list with field counts, pass flow (one-line reason, recorded against the order; 4 passes auto-raises escalation), rulebook-update toasts ("now in Spec §5"). → `listOrders`, `getQueue`, `passOrder`.
- **Review Screen** — the core screen. Left: scanned page image (`pageUrl(oid,n,dpi)`), right: flagged fields only. Dual-engine display with line-level highlight on disagreements; rule citations on flags; derived-value drill-down (`derived`); bug reporting with input-blame (`reportBug`); per-field confirm/fix (`postField` with `{field_path, action, page, was, now, confidence}`); approve blocks until all fields touched — server 409 returns `{untouched:[…]}` and the UI lists them.
- **Escalation Inbox** — unresolved escalations (multi-pass orders, rules gaps), resolve with disposition. → `escalations`, `escalation(id)`, `resolveEscalation`.
- **Ops Dashboard** — catch-rate headline (mono 52px, red when falling), reviewer rates with drill-in, source/county performance bars, field-backlog table. → `metrics`.
- **Delivery** — outbound report assembly; client portal is explicitly out of scope for v1.
- **Account** — rulebook home: 24 live rules R1–R24 (R13–R24 entered as one batch from the closed senior-searcher session), drafts pending counter, per-rule provenance.

**Measurement loop**
- **Golden Set** — the ground-truth order corpus; seed/curation status.
- **Extraction Bench** — run engines against the golden set; prompts regenerate from the rulebook (RuleContext in the engine interface), so a rulebook edit invalidates cached prompts.
- **Bench Results** — per-run field-level accuracy grids, engine vs engine.
- **Blind Fifty** — double-typing UI: two typists key the same order blind.
- **Blind Fifty Status** — funnel: A 18 · B 11 submitted, 7 ready for reconciliation (senior is the bottleneck when this grows), 3 reconciled, 4 rulebook drafts pending (amber >5, engineer needed >10). Judgments coverage is framed as **the only remaining gate** to judgment automation.
- **Reconciliation** — senior resolves typist divergences; **every ruling requires a rule citation** (R-number; UI enforces, e.g. R22 on judgment-type divergence). Rulings without citations are rejected.
- **Seed Correction** — corrections flow back into the golden set with audit trail.
- **Engine Leaderboard** — seats per (reader-slot × jurisdiction × doc-class) cell; promotion is config-flip, not deploy, and is logged (`{seat, cell, from, to, who, evidence}`). **Judgment automation gate: Claude agreement on judgment fields + ≥40 blind-fifty judgment fields reconciled.** Judgments never auto-confirm in v1.

## Interactions & Behavior
- Navigation: plain links between screens; no router state.
- Every mutating action is optimistic in the prototype with `.catch(()=>{})` — production should surface failures instead.
- Review Screen approve: disabled-looking until all flagged fields touched; on 409 shows the server's `untouched` list inline.
- Pass flow: input appears in place, ⏎ submits / esc cancels, confirmation note renders after.
- Drill-downs (Ops Dashboard, Leaderboard) are in-place expanding panels, not modals.
- Loading: screens render fallback data instantly, then swap to live (`setState({live:true,…})`) — no spinners.
- Hover states are defined inline via `style-hover` in the prototypes; carry them over.

## State Management
- Per-screen local state only; no global store needed. Server owns all business rules: field `state`, `needs_review`, queue order, derived values, gate evaluation. **The client never computes whether something auto-confirms.**
- `window.TITLEPIPE_BASE` overrides the API base (default `http://localhost:5000`).

## Backend — required work (the export target must implement ALL of this)
`api.js` is the contract. Implemented-in-brief endpoints:

`GET /api/orders` · `GET /api/orders/:id` · `GET /api/orders/:id/queue` · `GET /api/orders/:id/manifest` · `GET /api/orders/:id/page/:n?dpi=` (PNG) · `POST /api/orders/:id/field` · `POST /api/orders/:id/approve` (409 `{untouched}`) · `POST /api/upload` (multipart `package` + manifest) · `POST /api/orders/:id/accept` · `GET /api/metrics`

Specified but returning 404 until built (UI falls back; build these):
1. `GET /api/escalations`, `GET /api/escalations/:id`, `POST /api/escalations/:id/resolve` — plus the 4-passes auto-escalation trigger.
2. `POST /api/orders/:id/pass` `{reason, reviewer}` — recorded against the order.
3. `GET /api/orders/:id/derived/:fieldPath` — derivation inputs for drill-down.
4. `POST /api/orders/:id/bug` `{field_path, computed, reviewer_says, inputs, which_input_is_wrong, note, reviewer}`.
5. `GET /api/bench/leaderboard` → `{groups, cols, seats, log}`; `GET /api/routing`; `POST /api/routing/promote` `{seat, cell, from, to, who, evidence}` — promotion logging + config-flip routing.
6. **Rule-citation validation** on reconciliation rulings (reject citation-less rulings server-side, not just in UI).
7. **Claude gate** — high-stakes fields (amounts, legal descriptions, judgment TYPE) require Claude agreement before auto-confirm; judgments never auto-confirm in v1.
8. **Engine registry + ensemble routing** — two readers per cell with uncorrelated failures; auto-confirm only on agreement + validation + redundancy rules.
9. **Prompt generation from rulebook** — RuleContext compiled into engine prompts; rulebook edits invalidate.
10. Golden set / blind fifty / bench-run / reconciliation / rulebook CRUD (measurement screens currently run on embedded data — extend `api.js` with these).
11. The extraction layer itself (the "unsolved middle") — behind the single engine interface; everything above assumes it.

Rollout: P0–P6 phased, ending in shadow mode before any auto-confirm reaches production.

## Assets
None — no images or icon fonts. The only external dependency is Google Fonts (IBM Plex Sans + IBM Plex Mono). Page scans come from the backend PNG endpoint.

## Files
15 screens: `Review Screen.dc.html`, `Ingest.dc.html`, `Reviewer Queue.dc.html`, `Escalation Inbox.dc.html`, `Ops Dashboard.dc.html`, `Account.dc.html`, `Delivery.dc.html`, `Golden Set.dc.html`, `Extraction Bench.dc.html`, `Bench Results.dc.html`, `Blind Fifty.dc.html`, `Reconciliation.dc.html`, `Seed Correction.dc.html`, `Blind Fifty Status.dc.html`, `Engine Leaderboard.dc.html` — plus `api.js` (port this) and `support.js` (prototype runtime, reference only).
