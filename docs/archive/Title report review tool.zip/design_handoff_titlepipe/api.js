// titlepipe API adapter — the backend owns all rules (state, needs_review, queue order, derived values).
const BASE = (typeof window!=='undefined' && window.TITLEPIPE_BASE) || 'http://localhost:5000';
async function j(path, opts){
  const r = await fetch(BASE+path, opts);
  const ct = r.headers.get('content-type')||'';
  const body = ct.includes('json') ? await r.json() : null;
  if(!r.ok){ const e = new Error((body&&body.error)||('HTTP '+r.status)); e.status=r.status; e.body=body; throw e; }
  return body;
}
export const base = BASE;
export const listOrders = () => j('/api/orders');
export const getOrder   = (oid) => j('/api/orders/'+encodeURIComponent(oid));
export const getQueue   = (oid) => j('/api/orders/'+encodeURIComponent(oid)+'/queue');
export const getManifest= (oid) => j('/api/orders/'+encodeURIComponent(oid)+'/manifest');
export const pageUrl    = (oid,n,dpi=150) => BASE+'/api/orders/'+encodeURIComponent(oid)+'/page/'+n+'?dpi='+dpi;
export const postField  = (oid,payload) => j('/api/orders/'+encodeURIComponent(oid)+'/field',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
export const approve    = (oid,reviewer) => j('/api/orders/'+encodeURIComponent(oid)+'/approve',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reviewer})});
export const upload     = (formData) => j('/api/upload',{method:'POST',body:formData});
export const accept     = (oid) => j('/api/orders/'+encodeURIComponent(oid)+'/accept',{method:'POST'});
export const metrics    = () => j('/api/metrics');
// specified in the backend brief — wired here; 404 until implemented, callers must fall back
export const escalations = () => j('/api/escalations');
export const escalation  = (id) => j('/api/escalations/'+encodeURIComponent(id));
export const resolveEscalation = (id,body) => j('/api/escalations/'+encodeURIComponent(id)+'/resolve',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
export const passOrder   = (oid,reason,reviewer) => j('/api/orders/'+encodeURIComponent(oid)+'/pass',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reason,reviewer})});
export const derived     = (oid,fieldPath) => j('/api/orders/'+encodeURIComponent(oid)+'/derived/'+encodeURIComponent(fieldPath));
export const reportBug   = (oid,body) => j('/api/orders/'+encodeURIComponent(oid)+'/bug',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
// PRD §9 — engine leaderboard + per-cell routing (config, not deploy); 404 until implemented, callers must fall back
export const leaderboard = () => j('/api/bench/leaderboard');
export const routing     = () => j('/api/routing');
export const promoteSeat = (body) => j('/api/routing/promote',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
